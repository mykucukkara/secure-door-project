#include "LockController.h"

LockController::LockController(uint8_t relayPin)
    : relayPin(relayPin),
      unlockTimer(0),
      cooldownTimer(0),
      isUnlocked(false),
      isCoolingDown(false) {}

void LockController::begin() {
    // Bas-aç kilit icin role aktif-yuksek (HIGH) calisacak sekilde guncellendi.
    // Mod degistirilmeden once LOW yazarak acilista istemsiz tetiklemeyi onle.
    digitalWrite(relayPin, LOW);
    pinMode(relayPin, OUTPUT);

    Serial.printf(
        "[KILIT] GPIO%d PASIF/LOW (Kilit kapali). Okunan lojik=%d.\n",
        relayPin,
        digitalRead(relayPin)
    );
}

bool LockController::unlockDoor() {
    if (isCoolingDown || isUnlocked) {
        return false;
    }

    // Kapiyi acmak icin roleye guc veriliyor
    digitalWrite(relayPin, HIGH);
    isUnlocked = true;
    unlockTimer = millis();

    Serial.printf(
        "[KILIT] GPIO%d AKTIF/HIGH (Kilit acildi). Okunan lojik=%d; 2000 ms.\n",
        relayPin,
        digitalRead(relayPin)
    );
    return true;
}

void LockController::update() {
    const unsigned long now = millis();

    if (isUnlocked && now - unlockTimer >= UNLOCK_DURATION) {
        // Sure doldugunda kilidi tekrar kapat
        digitalWrite(relayPin, LOW);
        isUnlocked = false;
        isCoolingDown = true;
        cooldownTimer = now;

        Serial.printf(
            "[KILIT] GPIO%d PASIF/LOW. Tetikleme suresi=%lu ms.\n",
            relayPin,
            now - unlockTimer
        );
    }

    if (isCoolingDown && now - cooldownTimer >= COOLDOWN_DURATION) {
        isCoolingDown = false;
    }
}
